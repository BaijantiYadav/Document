import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicalFeesSystemComponent } from './medical-fees-system.component';

describe('MedicalFeesSystemComponent', () => {
  let component: MedicalFeesSystemComponent;
  let fixture: ComponentFixture<MedicalFeesSystemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MedicalFeesSystemComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalFeesSystemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
