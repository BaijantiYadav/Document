import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-medical-fees-system',
  templateUrl: './medical-fees-system.component.html',
  styleUrls: ['./medical-fees-system.component.css']
})
export class MedicalFeesSystemComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
