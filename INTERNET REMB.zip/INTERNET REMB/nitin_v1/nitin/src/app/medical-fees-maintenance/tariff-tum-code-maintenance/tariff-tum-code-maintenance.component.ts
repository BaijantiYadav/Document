import { Component, OnInit } from '@angular/core';
import {Location} from '@angular/common';
import { codeData } from 'src/app/shared/common/mock';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ALERTS, Alert } from '../../../app/shared/common/mock';
import { Tarifftumcodeassociation } from '../../../app/models/tarifftumcodeassociation';
import { MedicalFeesService } from '../../../app/services/medical-fees.service';

@Component({
  selector: 'app-tariff-tum-code-maintenance',
  templateUrl: './tariff-tum-code-maintenance.component.html',
  styleUrls: ['./tariff-tum-code-maintenance.component.css']
})
export class TariffTumCodeMaintenanceComponent implements OnInit {
  constructor( private _location: Location,
    private router: Router,
    private medicalFeesService: MedicalFeesService) { }


  searchText = '';
  noDataFound: any = 'No Record Found.';
  codeMaintenance:any;
  addModal: boolean = false;
  deleteModal: boolean = false;
  alerts: Alert[] = [];
  tumTariffAssociation!: Tarifftumcodeassociation[];
  tumCode!:Tarifftumcodeassociation;
  addRecordForm = new FormGroup({
    tumCode: new FormControl(''),
    description: new FormControl(''),
  });

  deleteRecordForm = new FormGroup({
    tumCodeDelete: new FormControl(''),
  });

  
  
  // constructor() {
  //   this.reset();
  // }

  close(alert: Alert) {
    this.alerts.splice(this.alerts.indexOf(alert), 1);
  }


  reset() {
    this.alerts = Array.from(ALERTS);
  }tructor() { }

  back() {
    this._location.back();
  }

  submitRecord(){
    this.medicalFeesService.save(this.addRecordForm.value).subscribe(result=>this.reset());
    //this.reset();
    console.log('Add', this.addRecordForm.value);
    this.router.navigate(['./medical-fees-maintenance/tum-tariff-association']);    
  }

  deleteRecord(){
    console.log('Delete', this.deleteRecordForm.value);    
  }

  openAddModal() {
   this.addModal = true;
   this.addRecordForm.reset();
  }

  openDeleteModal() {
    this.deleteModal = true;
    this.deleteRecordForm.reset();

  }
  onSearch(event: any) {
    if(event.value != '') {
      this.searchText = event.value; 
    } else {
      this.noDataFound = 'No Record Found.'
    }    
  }

  remove() {
    this.searchText = '';
    this.codeMaintenance = codeData;

  }
  ngOnInit(): void {
    console.log("hi");
     // this.codeMaintenance = codeData;
      //this.searchText = '';
      this.medicalFeesService.getAllTariffTumAssociation().subscribe(data=>{this.tumTariffAssociation=data
        
  
      
      });
      
      
  }

}
