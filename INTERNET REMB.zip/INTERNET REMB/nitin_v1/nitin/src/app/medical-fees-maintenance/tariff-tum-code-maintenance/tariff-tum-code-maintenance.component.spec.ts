import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TariffTumCodeMaintenanceComponent } from './tariff-tum-code-maintenance.component';

describe('TariffTumCodeMaintenanceComponent', () => {
  let component: TariffTumCodeMaintenanceComponent;
  let fixture: ComponentFixture<TariffTumCodeMaintenanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TariffTumCodeMaintenanceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TariffTumCodeMaintenanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
