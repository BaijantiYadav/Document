import { Component, OnInit, ViewChild } from '@angular/core';
import {Location} from '@angular/common';
import { codeData } from 'src/app/shared/common/mock';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ALERTS, Alert } from '../../../app/shared/common/mock';

@Component({
  selector: 'app-tariff-code-maintenance',
  templateUrl: './tariff-code-maintenance.component.html',
  styleUrls: ['./tariff-code-maintenance.component.css']
})
export class TariffCodeMaintenanceComponent implements OnInit {

  constructor(
    private _location: Location,
    private router: Router
    ) { }
  searchText = '';
  noDataFound: any = 'No Record Found.';
  codeMaintenance:any;
  addModal: boolean = false;
  deleteModal: boolean = false;
  alerts: Alert[] = [];
  addRecordForm = new FormGroup({
    tariffCode: new FormControl(''),
    description: new FormControl(''),
  });

  deleteRecordForm = new FormGroup({
    tariffCodeDelete: new FormControl(''),
  });
  
  // constructor() {
  //   this.reset();
  // }

  close(alert: Alert) {
    this.alerts.splice(this.alerts.indexOf(alert), 1);
  }

  reset() {
    this.alerts = Array.from(ALERTS);
  }tructor() { }

  back() {
    this._location.back();
  }

  submitRecord(){
    this.reset();
    console.log('Add', this.addRecordForm.value);
    this.router.navigate(['./medical-fees-maintenance/territory']);    
  }

  deleteRecord(){
    console.log('Delete', this.deleteRecordForm.value);    
  }

  openAddModal() {
   this.addModal = true;
   this.addRecordForm.reset();
  }

  openDeleteModal() {
    this.deleteModal = true;
    this.deleteRecordForm.reset();

  }
  onSearch(event: any) {
    console.log(event.value);
    if(event.value != '') {
      this.searchText = event.value; 
    } else {
      this.noDataFound = 'No Record Found.'
    }    
  }

  remove() {
    this.searchText = '';
    this.codeMaintenance = codeData;

  }
  ngOnInit(): void {
      this.codeMaintenance = codeData;
      this.searchText = '';
      
  }
}