import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TariffCodeMaintenanceComponent } from './tariff-code-maintenance.component';

describe('TariffCodeMaintenanceComponent', () => {
  let component: TariffCodeMaintenanceComponent;
  let fixture: ComponentFixture<TariffCodeMaintenanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TariffCodeMaintenanceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TariffCodeMaintenanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
