import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SpyLocation } from '@angular/common/testing';
import { TumCodeMaintenanceComponent } from './tum-code-maintenance.component';

describe('TumCodeMaintenanceComponent', () => {
  let component: TumCodeMaintenanceComponent;
  let fixture: ComponentFixture<TumCodeMaintenanceComponent>;
  let location: SpyLocation;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TumCodeMaintenanceComponent ],
      providers: [
        { provide: Location, useClass: SpyLocation }
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TumCodeMaintenanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    location = TestBed.get(Location);

  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have goBack method and should call location.back', () => {
    spyOn(location, 'back');
    component.back();
    expect(component.back).toBeDefined();
    expect(location.back).toHaveBeenCalled();
  });
});
});
