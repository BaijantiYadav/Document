import { Component, OnInit } from '@angular/core';
import {Location} from '@angular/common';
import { codeData } from 'src/app/shared/common/mock';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ALERTS, Alert } from '../../../app/shared/common/mock';
import { TumCodeMaintenance } from '../../../app/models/tum-code-maintenance';
import { MedicalFeesService } from '../../../app/services/medical-fees.service';

@Component({
  selector: 'app-tum-code-maintenance',
  templateUrl: './tum-code-maintenance.component.html',
  styleUrls: ['./tum-code-maintenance.component.css']
})
export class TumCodeMaintenanceComponent implements OnInit {

  constructor(
    private _location: Location,
    private router: Router,
    private medicalFeesService: MedicalFeesService
    ) { }
  searchText = '';
  noDataFound: any = 'No Record Found.';
  codeMaintenance:any;
  addModal: boolean = false;
  deleteModal: boolean = false;
  alerts: Alert[] = [];
  tumCodes!: TumCodeMaintenance[];
  tumCode!:TumCodeMaintenance;
  addRecordForm = new FormGroup({
    tumCode: new FormControl(''),
    description: new FormControl(''),
  });

  deleteRecordForm = new FormGroup({
    tumCodeDelete: new FormControl(''),
  });
  selectedEntry:any
  deleteTumCode:any;
  duplicateFound:boolean=false;
  duplicateModal:boolean=false;

  
  
  // constructor() {
  //   this.reset();
  // }

  close(alert: Alert) {
    this.alerts.splice(this.alerts.indexOf(alert), 1);
  }

  onSelectionChange(item:any) {
    this.selectedEntry = item;

}
  reset() {
    this.alerts = Array.from(ALERTS);
  }tructor() { }

  back() {
    this._location.back();
  }

  submitRecord(){
    for(let i=0;i<this.tumCodes.length;i++){
      console.log(this.addRecordForm.value.tumCode);
      if(this.tumCodes[i].tumCode.toLowerCase==this.addRecordForm.value.tumCode.toLowerCase){
        this.duplicateFound=true;
        break;
      }
      
    }
    if(this.duplicateFound){
      this.openDuplicateModal();
    }else{ 
      this.medicalFeesService.save(this.addRecordForm.value).subscribe(result=>this.reset());
    //this.reset();
      console.log('Add', this.addRecordForm.value);
      this.router.navigate(['./medical-fees-maintenance/tum-tariff-association']); 
    }  
    this.duplicateFound=false;
  }

  deleteRecord(){
    this.medicalFeesService.delete(this.selectedEntry.tumCode).subscribe(result=>
      console.log('Delete', this.deleteRecordForm.value)
    );   
    this.deleteModal = false;
  }

  openAddModal() {
   this.addModal = true;
   this.addRecordForm.reset();
  }

  openDeleteModal() {
    this.deleteModal = true;
    this.deleteRecordForm.reset();
    this.deleteTumCode = this.selectedEntry.tumCode;
    
    

  }
  onSearch(event: any) {
    if(event.value != '') {
      this.searchText = event.value; 
    } else {
      this.noDataFound = 'No Record Found.'
    }    
  }

  remove() {
    this.searchText = '';
    this.codeMaintenance = codeData;

  }
  ngOnInit(): void {
    console.log("hi");
     // this.codeMaintenance = codeData;
      //this.searchText = '';
      this.medicalFeesService.getAllTumCodes().subscribe(data=>{this.tumCodes=data
        
  
      
      });
      
      
  }

  openDuplicateModal() {
    this.duplicateModal = true;
    
   }

}
