import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TariffCodeMaintenanceComponent } from './tariff-code-maintenance/tariff-code-maintenance.component';
import { TariffTumCodeMaintenanceComponent } from './tariff-tum-code-maintenance/tariff-tum-code-maintenance.component';
import { SharedModule } from '../shared/shared-module/shared.module';
import { MedicalFeesRoutingModule } from './medical-fees-routing.module';
import { FilterPipe } from '../shared/pipe/filter.pipe';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TariffTerritoryMaintenanceComponent } from './tariff-territory-maintenance/tariff-territory-maintenance.component';
import { TumCodeMaintenanceComponent } from './tum-code-maintenance/tum-code-maintenance.component';
import { MedicalSourceSystemComponent } from './medical-source-system/medical-source-system.component';
import { MedicalSourceTariffCodeComponent } from './medical-source-tariff-code/medical-source-tariff-code.component';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';



@NgModule({
  declarations: [
    TariffCodeMaintenanceComponent,
    TariffTumCodeMaintenanceComponent,
    FilterPipe,
    TariffTerritoryMaintenanceComponent,
    TumCodeMaintenanceComponent,
    MedicalSourceSystemComponent,
    MedicalSourceTariffCodeComponent
  ],
  imports: [
    CommonModule,
    SharedModule,    
    MedicalFeesRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    HttpClientModule
  ],
  exports: [TariffCodeMaintenanceComponent,
    TariffTumCodeMaintenanceComponent, FilterPipe
  ],
  providers: [HttpClientModule],
})
export class MedicalFeesMaintenanceModule { }
