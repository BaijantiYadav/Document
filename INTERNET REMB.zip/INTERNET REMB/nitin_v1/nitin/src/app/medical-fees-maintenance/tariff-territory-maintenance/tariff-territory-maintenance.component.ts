import { Component, OnInit } from '@angular/core';
import {Location} from '@angular/common';

@Component({
  selector: 'app-tariff-territory-maintenance',
  templateUrl: './tariff-territory-maintenance.component.html',
  styleUrls: ['./tariff-territory-maintenance.component.css']
})
export class TariffTerritoryMaintenanceComponent implements OnInit {

  constructor(private _location: Location) { }


  back() {
    this._location.back();
  }
  ngOnInit(): void {
  }

}
