import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TariffTerritoryMaintenanceComponent } from './tariff-territory-maintenance.component';

describe('TariffTerritoryMaintenanceComponent', () => {
  let component: TariffTerritoryMaintenanceComponent;
  let fixture: ComponentFixture<TariffTerritoryMaintenanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TariffTerritoryMaintenanceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TariffTerritoryMaintenanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
