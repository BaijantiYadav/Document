import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MedicalSourceSystemComponent } from './medical-source-system/medical-source-system.component';
import { MedicalSourceTariffCodeComponent } from './medical-source-tariff-code/medical-source-tariff-code.component';
import { TariffCodeMaintenanceComponent } from './tariff-code-maintenance/tariff-code-maintenance.component';
import { TariffTerritoryMaintenanceComponent } from './tariff-territory-maintenance/tariff-territory-maintenance.component';
import { TariffTumCodeMaintenanceComponent } from './tariff-tum-code-maintenance/tariff-tum-code-maintenance.component';
import { TumCodeMaintenanceComponent } from './tum-code-maintenance/tum-code-maintenance.component';
import { HttpClientModule } from '@angular/common/http';

const routes: Routes = [
    { path: '', redirectTo: '/tariff-code', pathMatch: 'full' },
    { path: 'tariff-code', component: TariffCodeMaintenanceComponent},
    { path: 'territory', component: TariffTerritoryMaintenanceComponent},
    { path: 'tum-code', component: TumCodeMaintenanceComponent},
    { path: 'tum-tariff-association', component: TariffTumCodeMaintenanceComponent},
    { path: 'medical-source', component: MedicalSourceSystemComponent},
    { path: 'medical-source-association', component: MedicalSourceTariffCodeComponent},
  ];

@NgModule({
  imports: [ 
    RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [HttpClientModule]
})
export class MedicalFeesRoutingModule { }