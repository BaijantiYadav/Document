import { Component, OnInit } from '@angular/core';
import {Location} from '@angular/common';

@Component({
  selector: 'app-medical-source-system',
  templateUrl: './medical-source-system.component.html',
  styleUrls: ['./medical-source-system.component.css']
})
export class MedicalSourceSystemComponent implements OnInit {

  constructor(private _location: Location) { }


  back() {
    this._location.back();
  }
  ngOnInit(): void {
  }

}
