import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicalSourceSystemComponent } from './medical-source-system.component';

describe('MedicalSourceSystemComponent', () => {
  let component: MedicalSourceSystemComponent;
  let fixture: ComponentFixture<MedicalSourceSystemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MedicalSourceSystemComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalSourceSystemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
