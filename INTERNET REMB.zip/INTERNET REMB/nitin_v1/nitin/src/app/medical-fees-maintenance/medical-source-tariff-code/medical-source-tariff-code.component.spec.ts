import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicalSourceTariffCodeComponent } from './medical-source-tariff-code.component';

describe('MedicalSourceTariffCodeComponent', () => {
  let component: MedicalSourceTariffCodeComponent;
  let fixture: ComponentFixture<MedicalSourceTariffCodeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MedicalSourceTariffCodeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalSourceTariffCodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
