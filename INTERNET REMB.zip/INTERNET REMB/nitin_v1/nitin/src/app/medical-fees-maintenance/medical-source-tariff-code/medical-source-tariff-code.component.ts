import { Component, OnInit } from '@angular/core';
import {Location} from '@angular/common';

@Component({
  selector: 'app-medical-source-tariff-code',
  templateUrl: './medical-source-tariff-code.component.html',
  styleUrls: ['./medical-source-tariff-code.component.css']
})
export class MedicalSourceTariffCodeComponent implements OnInit {

  constructor(private _location: Location) { }


  back() {
    this._location.back();
  }
  ngOnInit(): void {
  }

}
