export class TumCodeMaintenance {

    tumCode!: string;
    description!: string;
}
