import { TumCodeMaintenance } from './tum-code-maintenance';

describe('TumCodeMaintenance', () => {
  it('should create an instance', () => {
    expect(new TumCodeMaintenance()).toBeTruthy();
  });
});
