export class Tarifftumcodeassociation {

    tumCode!: string;
    tariffCode!: string;
    territory!:string;
}
