import { Tarifftumcodeassociation } from './tarifftumcodeassociation';

describe('Tarifftumcodeassociation', () => {
  it('should create an instance', () => {
    expect(new Tarifftumcodeassociation()).toBeTruthy();
  });
});
