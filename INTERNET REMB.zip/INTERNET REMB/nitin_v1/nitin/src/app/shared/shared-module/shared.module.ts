import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SideNavComponent } from '../component/side-nav/side-nav.component';
import { RouterModule } from '@angular/router';
// import { FilterPipe } from '../pipe/filter.pipe';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';



@NgModule({
  declarations: [SideNavComponent, ],
  imports: [
    CommonModule,
    RouterModule,
    NgbModule
  ],
  exports: [
    CommonModule,
    NgbModule,
    SideNavComponent,
    
  ]
})
export class SharedModule { }
