import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter',
  pure: false,
})
export class FilterPipe implements PipeTransform {
    searchText:any;
  transform(items: any[], searchText: string): any[] {
    if (!items) {
      return [];
    }
    if (!searchText) {
      return items;
    }
    this.searchText = searchText.toLowerCase();
    const users = [];
    for (let user of items) {
       const key1 = user['tumCode'].toLowerCase();
       const key2 = user['description'].toLowerCase();
      if (key1 === searchText.toLowerCase() || key2 === searchText.toLowerCase()) {
        users.push(user);
      }
    }
    return users;
  }
}
