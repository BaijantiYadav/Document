export const codeData = [
    {
        "tariffCode": "AAA",
        "description": "123"
    },
    {
        "tariffCode": "AAA12",
        "description": "TEST"
    },
    {
        "tariffCode": "ABCD",
        "description": "ABCD"
    },
    {
        "tariffCode": "ALT",
        "description": "TRANSAMINASES ( ALT )"
    },
    {
        "tariffCode": "AST",
        "description": "TRANSAMINASES ( ALT )"
    },
    {
        "tariffCode": "ASM",
        "description": "DUMMY"
    },
    {
        "tariffCode": "A1101",
        "description": "STANDARD MEDICAL WITH COPIES"
    },
    {
        "tariffCode": "A1102",
        "description": " STANDARD MEDICAL REPORT WITHOUT ANY COPIES OF SPECIALIST REP"
    },
    {
        "tariffCode": "A1103",
        "description": "SHORT MEDICAL REPORT (LENGTH, WEIGHT, CHEST- + ABDOMEN GIRTH"
    },
    {
        "tariffCode": "A1106",
        "description": "THREE BLOOD PRESSURE READINGS "
    },
    {
        "tariffCode": "5221",
        "description": "HIV ELISA FIRST TEST "
    },
    {
        "tariffCode": "5224",
        "description": "FASTING BLOOD SUGAR"
    }
]

export interface Alert {
    type: string;
    message: string;
  }
export const ALERTS: Alert[] = [{
    type: 'success',
    message: 'New Tariff Code Added for Territory Association.',
  },
//    {
//     type: 'info',
//     message: 'This is an info alert',
//   }, {
//     type: 'warning',
//     message: 'This is a warning alert',
//   }, {
//     type: 'danger',
//     message: 'This is a danger alert',
//   }, {
//     type: 'primary',
//     message: 'This is a primary alert',
//   }, {
//     type: 'secondary',
//     message: 'This is a secondary alert',
//   }, {
//     type: 'light',
//     message: 'This is a light alert',
//   }, {
//     type: 'dark',
//     message: 'This is a dark alert',
//   }
];