import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MedicalFeesSystemComponent } from './medical-fees-system/medical-fees-system.component';

const routes: Routes = [
  // { path: '', component: HomeComponent, },
  {
    path: '',
    component: MedicalFeesSystemComponent
  },
  {
    path: 'medical-fees-maintenance',
    loadChildren: () => import('././medical-fees-maintenance/medical-fees-maintenance.module')
      .then(mod => mod.MedicalFeesMaintenanceModule)
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
