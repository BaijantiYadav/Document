import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders }from '@angular/common/http';
import { Observable } from 'rxjs';
import { TumCodeMaintenance } from '../models/tum-code-maintenance';

@Injectable({
  providedIn: 'root'
})
export class MedicalFeesService {

  baseUrl='http://localhost:8080';

  private tumCodeMaintenanceUrl!: string;
 
  constructor(private http:HttpClient) { 
    
  }

  public getAllTumCodes():
  Observable<TumCodeMaintenance[]>{
    return this.http.get<TumCodeMaintenance[]>(this.baseUrl+'/tumDetails');
  }

  public save(tumDetails:TumCodeMaintenance){
    return this.http.post<TumCodeMaintenance>('http://localhost:8080/savetumDetails',tumDetails);
  }

  public getAllTariffTumAssociation():Observable<any>{
    return this.http.get<any>(this.baseUrl+'/tariffTumAssociation');
  }

  public delete(tumCode:any){
    return this.http.post<any>('http://localhost:8080/deleteTumCode',tumCode);
  }
}
