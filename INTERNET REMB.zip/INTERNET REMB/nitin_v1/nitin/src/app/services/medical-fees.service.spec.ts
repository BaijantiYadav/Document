import { TestBed } from '@angular/core/testing';

import { MedicalFeesService } from './medical-fees.service';

describe('MedicalFeesService', () => {
  let service: MedicalFeesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MedicalFeesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
